#include "m19445.h"

const Foo f = {10, 20, 30, 40};