This directory contains helper files used by several tests, to avoid
code duplication, akin to a std extension tailored for testament.

Some of these could later migrate to stdlib.
